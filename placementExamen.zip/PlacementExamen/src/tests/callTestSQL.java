package tests;

import java.sql.SQLException;

import main.CallSQL;

public class callTestSQL {
		
	public static void main(String[] args) {
		
//		try {
//			String req = CallSQL.getStudentIdentity();
//			
//			System.out.println(req);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
//		try {
//			String req = CallSQL.selectAllUserID();
//			
//			System.out.println(req);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		try {
//			String req = CallSQL.selectNameStudL1Info();
//			
//			System.out.println(req);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		try {
//			String req = CallSQL.roomDispo();
//			
//			System.out.println(req);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		try {
//			String req = CallSQL.roomsDispoFixedSchedule();
//			
//			System.out.println(req);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
//		try {
//			String req = CallSQL.roomsAndSchedule();
//			
//			System.out.println(req);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		
		
		// WIPed CLASS
//		try {
//			CallSQL.setOneUserID("\"michel.carver@gmail.com\"");
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
//		try {
//			String req = CallSQL.update();
//			System.out.println(req);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		try{
//			CallSQL.newExamen();
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		try{
//			CallSQL.uptadeExamen();
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}	
	
}
}