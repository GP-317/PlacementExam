package main;



public class Examen {
	private static String TITLE;
	private static String DURATION;
	private static String TEACHER_SUPERVISOR;
	private static String MATERIAL;
	private static String START_TIME;
	

	public static String getTitle() {
		return TITLE;
	}
	public void setTitle(String Title) {
		Examen.TITLE = Title;
	}
	public static String getDURATION() {
		return DURATION;
	}
	public void setDURATION(String DURATION) {
		Examen.DURATION = DURATION;
	}
	public static String getMATERIAL() {
		return MATERIAL;
	}
	public void setMATERIAL(String mATERIAL) {
		Examen.MATERIAL = mATERIAL;
	}
	public static String getSTART_TIME() {
		return START_TIME;
	}
	public void setSTART_TIME(String sTART_TIME) {
		Examen.START_TIME = sTART_TIME;
	}
	public static String getTEACHER_SUPERVISOR() {
		return TEACHER_SUPERVISOR;
	}
	public void setTEACHER_SUPERVISOR(String tEACHER_SUPERVISOR) {
		Examen.TEACHER_SUPERVISOR = tEACHER_SUPERVISOR;
	}
}
