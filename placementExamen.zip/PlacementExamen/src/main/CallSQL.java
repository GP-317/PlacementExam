package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


/**
 * Classe inventoriant toutes les m�thodes d'usage des requ�tes SQL
 * @author Geoffrey
 *
 */
public class CallSQL {
	//private static String USER_PROFILE;
	/**
	 * Les trois attributs codifi�s pirvate constituent le coeur de la connexion � la base de donn�es.
	 * Si user et mdp sont vou�s � changer, plus tard, pour se conformer aux ID des utilisateurs et aux
	 * mots de passe de ces derniers, url ne devra, a priori, jamais changer � moins de modifier l'emplacement
	 * de la base de donn�es.
	 */
	private static	String 
			url = "jdbc:mysql://localhost:3306/dbproject"				
				+"?useSSL=false&useUnicode=true"
					+"&useJDBCCompliantTimezoneShift=true"
						+"&useLegacyDatetimeCode=false"
							+"&serverTimezone=UTC"
								+"&allowPublicKeyRetrieval=true";
	private static String user = "root";
	private static String mdp = "";
	static Connection cn = null;
	/**
	 * La m�thode getSutdentIdentity r�cup�re le contenu de la table Eleve, transportant par une cha�ne de caract�res
	 * @throws SQLException
	 */
	public static void getStudentIdentity() throws SQLException {

		cn = DriverManager.getConnection(url, user, mdp);

		Statement st = cn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM Eleve");
		ResultSetMetaData resultMeta = rs.getMetaData();


		System.out.println("\n**********************************");
		//On affiche le nom des colonnes
		for(int i = 1; i <= resultMeta.getColumnCount(); i++)
			System.out.print("\t" + resultMeta.getColumnName(i).toUpperCase() + "\t *");

		System.out.println("\n**********************************");

		while(rs.next()){         
			for(int i = 1; i <= resultMeta.getColumnCount(); i++)				//Permet la recherche du type des colonnes
				System.out.print("\t" + rs.getObject(i).toString() + "\t |");	//L'avantage de cet appel de m�thode r�side dans
																				//le caract�re inconnu du type.
			System.out.println("\n---------------------------------");

		}

	}
	
	
	
	/**
	 * M�thode permettant la s�lection des nom et pr�nom de tous les utilisateurs de la base de donn�es
	 * @return str, une chaine de caract�res contenant les nom et pr�nom des utilisateurs de la bdd
	 * @throws SQLException
	 */
	public static String selectAllUserID() throws SQLException {
		
		cn = DriverManager.getConnection(url, user, mdp);

		Statement st = cn.createStatement();
		ResultSet rs = st.executeQuery("SELECT nom, prenom FROM Utilisateur");
		ResultSetMetaData resultMeta = rs.getMetaData();
		String str = "";
		
			while(rs.next()) {
				for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				str += rs.getObject(i).toString() + " ";
				}
			}
			
			return str;
		
	}
	
	
	/**
	 * Affiche le nom des eleves qui sont dans la filliere L1 Info
	 * @return str chaine de caract�res compos�e des noms susmentionn�s
	 * @throws SQLException
	 */
	public static String selectNameStudL1Info() throws SQLException {
		
		cn = DriverManager.getConnection(url, user, mdp);

		Statement st = cn.createStatement();
		ResultSet rs = st.executeQuery(	"SELECT  El.nom FROM\r\n" + 						//SELECT  El.nom FROM
							"Examen E INNER JOIN Filiere F \r\n" + 					//Examen E INNER JOIN Filiere F
								"ON E.idExamen = F.Examen_idExamen\r\n" + 					//ON E.idExamen = F.Examen_idExamen
									"INNER JOIN Eleve El\r\n" + 									//INNER JOIN Eleve El
										"ON El.Filiere_idFiliere=F.idFiliere\r\n" + 						//ON El.Filiere_idFiliere=F.idFiliere
											"WHERE nomFiliere='L1 Info'");											//WHERE nomFiliere='L1 Info'
		ResultSetMetaData resultMeta = rs.getMetaData();
		String str = "";
		
		while(rs.next()) {
			for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
			str += rs.getObject(i).toString() + " ";
			}
		}
		
		return str;
		
	}
	
	
	
	/**
	 * M�thode renvoyant quelles salles sont disponibles
	 * La v�rification se r�alise par la comparaison sur un bool�en au sein de la table
	 * @return str, une chaine de caract�res
	 * @throws SQLException
	 */
	public static String roomDispo() throws SQLException {
		
		cn = DriverManager.getConnection(url, user, mdp);

		Statement st = cn.createStatement();
		ResultSet rs = st.executeQuery("SELECT S.nom FROM Salle S \r\n" + 
				"WHERE dispo =1");
		ResultSetMetaData resultMeta = rs.getMetaData();
		String str = "";
		
		while(rs.next()) {
			for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
			str += rs.getObject(i).toString() + " ";
			}
		}
		
		return str;
		
	}
	
	
	/**
	 * Affiche le nom des salles disponibles � un horaire pr�d�fini (qui pourra, plus tard, �tre chang� au gr� de l'utilisateur)
	 * @return str, une cha�ne de carract�res
	 * @throws SQLException
	 */
	public static String roomsDispoFixedSchedule() throws SQLException {
		
		cn = DriverManager.getConnection(url, user, mdp);

		Statement st = cn.createStatement();
		ResultSet rs = st.executeQuery("SELECT S.nom FROM Salle S INNER JOIN Salle_has_PlageHoraire SP\r\n" + 
				"ON S.idSalle=SP.Salle_idSalle\r\n" + 
				"INNER JOIN PlageHoraire P\r\n" + 
				"ON P.idPlageHoraire=SP.PlageHoraire_idPlageHoraire\r\n" + 
				"WHERE S.dispo=1 AND P.date= '2019-11-21' AND P.intervallePlaHor= '1012'");
		ResultSetMetaData resultMeta = rs.getMetaData();
		String str = "";
		
		while(rs.next()) {
			for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
			str += rs.getObject(i).toString() + " ";
			}
		}
		
		return str;
		
	}
	
	
	/**
	 * Affiche, plus cr�ment, les salles et les horaires qui leur sont attribu�s.
	 * @return str, cha�ne de caract�res
	 * @throws SQLException
	 */
	public static String roomsAndSchedule() throws SQLException {
		
		cn = DriverManager.getConnection(url, user, mdp);

		Statement st = cn.createStatement();
		ResultSet rs = st.executeQuery("SELECT S.nom, PH.date, PH.intervallePlaHor \r\n" + 
				"FROM Salle S INNER JOIN Salle_has_PlageHoraire SP\r\n" + 
				"ON SP.Salle_idSalle = S.idSalle INNER JOIN PlageHoraire PH \r\n" + 
				"ON PH.idPlageHoraire = SP.PlageHoraire_idPlageHoraire");
		ResultSetMetaData resultMeta = rs.getMetaData();
		String str = "";
		
		
		
		for(int i = 1; i <= resultMeta.getColumnCount(); i++)
			System.out.print("\t" + resultMeta.getColumnName(i).toUpperCase() + "\t *");

		System.out.println("\n**********************************************************");
		
		while(rs.next()){         
			for(int i = 1; i <= resultMeta.getColumnCount(); i++)				
				System.out.print("\t" + rs.getObject(i).toString() + "\t |");	
															
			System.out.println("\n----------------------------------------------------------");

		}
		
		return str;
	}
	
	
	
	
	/**
	 * WIP
	 */
	
//	public static void setOneUserID(String login) throws SQLException {
//		
//		cn = DriverManager.getConnection(url, user, mdp);
//
//		Statement st = cn.createStatement();
//		ResultSet rs = st.executeQuery("SELECT nom FROM Utilisateur"
//				+ "WHERE email =" + login);
//		ResultSetMetaData resultMeta = rs.getMetaData();
//		String str = "";
//		
//		while(rs.next()) {
//			for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
//				str += rs.getObject(i).toString();
//			}
//		}
//		System.out.println(str);
//		
//		utilisateur setting = new utilisateur(str, mdp);
//		String alfa = setting.getUserID();
//		
//		System.out.println(alfa);
//		
//	}
		
	
	/**
	 * Met � jour la banque de donn�es
	 * M�thode manuellement param�tr�e mais pourra �tre automatique par la suite
	 * @return str renvoie une chaine de caract�res
	 * @throws SQLException
	 */
	public static String update() throws SQLException {
		
		cn = DriverManager.getConnection(url, user, mdp);

		Statement st = cn.createStatement();
		String rs = "UPDATE Profil"
				+ "\n SET nomProfil = 'Secretariat'"
				+ "\n WHERE idProfil = 1";
		
		st.executeUpdate(rs);
		String str ="";
		
		ResultSet result = st.executeQuery("SELECT nomProfil from Profil");
		ResultSetMetaData resultMeta = result.getMetaData();
		
		while(result.next()) {
			for(int i = 1; i <= resultMeta.getColumnCount(); i++)
				str += result.getObject(i).toString();
		}
		return str;
	}
	/**
	 * Ajouter un nouveau examen
	 * M�thode manuellement param�tr�e
	 * @throws SQLException
	 */

//	public static boolean compareProfile(){
//		
//		Utilisateur.USER_PROFILE=="Secretaire"|| Utilisateur.USER_PROFILE=="Scolarite";
//		if(true) {
//		}
//			
//		else System.out.println("Vous n'etez pas un secretaire n'y une personne qui travail a la scolarite");
//		return false;
//}
	public static void newExamen() throws SQLException{
		
		cn = DriverManager.getConnection(url, user, mdp);
		PreparedStatement  st = cn.prepareStatement("INSERT�INTO�examen�(idExamen,�titre,�duree,�"
				+ "profSurveillant,�matiere,tempsDebut)"
				 +"� VALUES (NULL, ?, ?, ?, ?, ?)");
		System.out.println("Veuillez saisir un titre d'examen : ");
		Scanner t = new Scanner(System.in);
		String x= t.nextLine();
		st.setString(1,x);
		
		System.out.println("Veuillez saisir une dur�e d'examen ex 02:00:00 : ");
		Scanner d= new Scanner(System.in);
		String y= d.nextLine();
		st.setString(2,y);
		
		System.out.println("Veuillez saisir le ou les noms/prenoms des profs surveillant de l'examen : ");
		Scanner t1= new Scanner(System.in);
		String b= t1.nextLine();
		st.setString(3,b);
		
		System.out.println("Veuillez saisir la matiere de l'examen : ");
		Scanner m= new Scanner(System.in);
		String z = m.nextLine();
		st.setString(4,z);
		
		System.out.println("Veuillez saisir la date et l'heure de l'examen ex: 2018-12-31 10:30:00  : ");
		Scanner s= new Scanner(System.in);
		String p= s.nextLine();
		st.setString(5,p);
		st.execute();
	}
	public static void uptadeExamen() throws SQLException{
		
		cn = DriverManager.getConnection(url, user, mdp);
		PreparedStatement  st = cn.prepareStatement("UPDATE examen SET titre =?, duree=?, profSurveillant=?,matiere=?, tempsDebut =? WHERE idExamen =?");

		System.out.println("Veuillez saisir ici la nouveau titre de l'examen  :");		
		Scanner t = new Scanner(System.in);
		String x= t.nextLine();
		st.setString(1,x);
		
		System.out.println("Veuillez saisir la nouvelle duree : ");
		Scanner d= new Scanner(System.in);
		String y= d.nextLine();
		st.setString(2,y);
		
		
		System.out.println("Veuillez saisir le profSurveillant : ");
		Scanner t1= new Scanner(System.in);
		String b= t1.nextLine();
		st.setString(3,b);
		
		System.out.println("Veuillez saisir la nouvelle matiere  : ");
		Scanner m= new Scanner(System.in);
		String z = m.nextLine();
		st.setString(4,z);
		
		System.out.println("Veuillez saisir la nouvelle date et l'heure de l'examen ex: 2018-12-31 10:30:00  : ");
		Scanner s= new Scanner(System.in);
		String p= s.nextLine();
		st.setString(5,p);
		
		System.out.println("Veuillez saisir la nouvelle id : ");
		Scanner i= new Scanner(System.in);
		int f= i.nextInt();
		st.setInt(6,f);
		st.executeUpdate();
	}
}

