package main;

public class Scolarite extends Utilisateur{

	protected String USER_MDP;
	private String USER_ID;
	private String USER_PROFILE;
	/**
	 * @param userID ID de l'utilisateur
	 * @param userMDP le mot de passe de l'utilisateur
	 * @return 
	 */

	public Scolarite(String userID, String userMDP, String userProfile) {
		super(userID, userMDP , userProfile);
		this.USER_ID=userID;
		this.USER_MDP=userMDP;
		this.USER_PROFILE=userProfile;
}
	public String getUserID(){
	return this.USER_ID;
	}

	public String getUserMDP() {
		return this.USER_MDP;
	}
	public String getProfile(){
		return this.USER_PROFILE;
}
	public void setProfile(String userProfile) {
		this.USER_PROFILE = userProfile;
}
	public void setUserID(String user) {
		this.USER_ID = user;
	}

	public void setUserMDP(String mdp) {
		this.USER_MDP = mdp;
	}
}
