package main;
public class Secretariat extends Utilisateur {

	private String USER_ID;
	private String USER_MDP;
	private String USER_PROFILE;
	
	/**
	 * Les trois attributs codifi�s pirvate constituent le coeur de la connexion � la base de donn�es.
	 * Si user et mdp sont vou�s � changer, plus tard, pour se conformer aux ID des utilisateurs et aux
	 * mots de passe de ces derniers, url ne devra, a priori, jamais changer � moins de modifier l'emplacement
	 * de la base de donn�es.
	 */


	public Secretariat(String USER_ID, String userMDP, String USER_PROFILE) {
		/**
		 * @param userID ID de l'utilisateur
		 * @param userMDP le mot de passe de l'utilisateur
		 * @return 
		 */
		super(USER_ID, userMDP, USER_PROFILE);
		this.USER_ID = USER_ID;
		this.USER_MDP = userMDP;
		this.USER_PROFILE= USER_PROFILE;
		// TODO Auto-generated constructor stub
	}
	public String getUserID(){
		return this.USER_ID;
	}
	public String getUserMDP() {
		return this.USER_MDP;
	}
	public String getProfile(){
		return this.USER_PROFILE;
}
	public void setProfile(String userProfile) {
		this.USER_PROFILE = userProfile;
}
	
	public void setUserID(String user) {
		this.USER_ID = user;
	}
	
	public void setUserMDP(String mdp) {
		this.USER_MDP = mdp;
	}	
	
}
