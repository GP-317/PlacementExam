package main;

import java.util.Random;

public class Administrateur extends Utilisateur{

	protected String USER_MDP;
	private String USER_ID;
	private String USER_PROFILE;
	/**
	 * @param userID ID de l'utilisateur
	 * @param userMDP le mot de passe de l'utilisateur
	 * @return 
	 */

	public Administrateur(String userID, String userMDP, String userProfile) {
		super(userID, userMDP, userProfile);
		// TODO Auto-generated constructor stub
		this.USER_ID=userID;
		this.USER_MDP=userMDP;
		this.USER_PROFILE=userProfile;
}
	public String getUserProfile(){
		return this.USER_PROFILE;
		}
	public String getUserID(){
	return this.USER_ID;
	}

	public String getUserMDP() {
		return this.USER_MDP;
	}

	public void setUserID(String user) {
		this.USER_ID = user;
	}
	
	public void setUserProfile(String UserProfil) {
		this.USER_PROFILE = UserProfil;
	}
	

	public void setUserMDP(String mdp) {
		this.USER_MDP = mdp;
	}
	
	public String newMDP(){
		Random rand = new Random();
		String userMDP1 = "abcd1235";
		int longueur =8;
		for(int i = 0; i < 8; i++) {
		  int k = rand.nextInt(longueur);
		  System.out.print(userMDP1.charAt(k));
		}
		 return this.USER_MDP = userMDP1;
	}
}
