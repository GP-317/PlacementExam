package tests;
import main.Administrateur;
public class Test {
		public static void main(String[] args) {
			/**
			 * Methode qui cr�e un secretaire 
			 * s.getUserID renvoie la valeur de  UserID en fonction de s
			 * s.getUserMDP renvoie la valeur de  UserMDP en fonction de s 
			 * s.getUserProfile renvoie la valeur de  UserProfiles en fonction de s
			 */
//			Secretariat s = new Secretariat("ahmet","josef", "Secretariat");
//			
//			System.out.println(s.getUserID());
//			System.out.println(s.getUserMDP());
//			System.out.println(s.getUserProfile());
			
			/**
			 * Methode qui cr�e une personne qui travaille a la scolarit� 
			 * sc.getUserID() renvoie la valeur de  dans UserID en fonction de sc
			 * sc.getUserMDP() renvoie la valeur de  dansUserMDP en fonction de sc
			 * sc.getUserProfile() renvoie la valeur de  dans Userprofile en fonction de sc
			 */ 
//			Scolarite sc = new Scolarite("Joseph", "c'estquoiunmdp?", "Scolarite");
	//
//			System.out.println("Pseudo : "+sc.getUserID());
//			System.out.println("Mot de passe : "+sc.getUserMDP());
//	 		System.out.println("Profil : "+sc.getUserProfile());
			/**
			 * Methode qui cr�e un administrateur 
			 * sc.getUserID() renvoie la valeur de   UserID en fonction de a
			 * sc.getUserMDP() renvoie la valeur de  UserMDP en fonction de a
			 * sc.getUserProfile() renvoie la valeur de   Userprofile en fonction de a
			 */ 
//			Administrateur a = new Administrateur("Ahmet", "Joseph <3 Ahmet", "Administrateur");
	//
//			System.out.println("Pseudo : "+a.getUserID());
//			System.out.println("Mot de passe : "+a.getUserMDP());
//	 		System.out.println("Profil : "+a.getUserProfile());

			/**
			 * Methode qui cr�e un nouveau mot passe  
			 * sc.getUserID() renvoie la valeur de   UserID en fonction de a
			 * a.newMDP()() renvoie le nouveau mot de passe 
			 * sc.getUserProfile() renvoie la valeur de   Userprofile en fonction de a
			 */ 
			
			
//			Administrateur a = new Administrateur("Ahmet", "Joseph <3 Ahmet", "Administrateur");
//					
//			System.out.println("Pseudo : "+a.getUserID());
//			System.out.println("Nouveaux Mot de passe : "+a.newMDP());
//			System.out.println("Profil :" +a.getUserProfile() );
			
			/**
			 * Methode qui change le profil de l'utilisateur  
			 * a.getUserID() renvoie la valeur de UserID en fonction de a 
			 * a.setUserProfile() insert la nouvelle valeur de a dans Userprofile 
			 * a.getUserProfile() renvoie la valeur de  Userprofile en fonction de a 
			 */ 
			
//			
//			Administrateur a = new Administrateur("Ahmet", "Joseph <3 Ahmet", "Administrateur");		
//
//			System.out.println("Pseudo : "+a.getUserID());
//			a.setUserProfile("Secr�tariat");
//			System.out.println("Profil :" +a.getUserProfile() );
//
//			
		}
	}

